/*Method used for filtering data*/
async function filter() {
    try {
        /*User input variable and arrays for data*/
        let names = document.getElementById('text').value;
        var resnames = [];
        var starsCount = [];
        var forkCount = [];
        var hasPro = [];

        /*Input validation*/
        if (names == '') {
            alert("Please fill out all fields!");
            return false;
        }

        /*Part of the code used for fetching respositories names*/
        const url = "https://api.github.com/search/repositories?q=" + names;
        const response = await fetch(url);
        const result = await response.json();

        result.items.forEach(i => {

            const anchor = document.createElement("a")
            anchor.href = i.html_url;
            anchor.textContent = i.full_name;
            resnames.push(anchor.textContent);

            const anchor2 = document.createElement("a")
            anchor2.href = i.html_url;
            anchor2.textContent = i.stargazers_count;
            starsCount.push(anchor2.textContent);

            const anchor3 = document.createElement("a")
            anchor3.href = i.html_url;
            anchor3.textContent = i.has_projects;
            hasPro.push(anchor3.textContent);

            const anchor4 = document.createElement("a")
            anchor4.href = i.html_url;
            anchor4.textContent = i.forks_count;
            forkCount.push(anchor4.textContent);
        })

        /*Part of the code that checks if respository exists with noReps() method.
        If exists it splits name into two parts and prints it out*/
        if (resnames.length == 0) {
            noResps();
        } else {
            let array1 = resnames[0].split("/");
            let array2 = resnames[1].split("/");
            let array3 = resnames[2].split("/");

            document.getElementById("resname1").innerHTML = array1[0] + "<br>" + array1[1];
            document.getElementById("resname2").innerHTML = array2[0] + "<br>" + array2[1];
            document.getElementById("resname3").innerHTML = array3[0] + "<br>" + array3[1];
        }

        /*Code that changes true or false to yes and no*/
        for (let i = 0; i < hasPro.length; i++) {
            if (hasPro[i] == "true") {
                hasPro[i] = "Yes";
            } else {
                hasPro[i] = "No";
            }

            /*Code that puts data on the webpage*/
            document.getElementById("star1").innerHTML = "Stars: " + starsCount[0];
            document.getElementById("star2").innerHTML = "Stars: " + starsCount[1];
            document.getElementById("star3").innerHTML = "Stars: " + starsCount[2];

            document.getElementById("fork1").innerHTML = "Forks: " + forkCount[0];
            document.getElementById("fork2").innerHTML = "Forks: " + forkCount[1];
            document.getElementById("fork3").innerHTML = "Forks: " + forkCount[2];

            document.getElementById("project1").innerHTML = "Has projects: " + hasPro[0];
            document.getElementById("project2").innerHTML = "Has projects: " + hasPro[1];
            document.getElementById("project3").innerHTML = "Has projects: " + hasPro[2];

            return true;
        }
    } catch (er) {
        alert("GitHub API rate limit is reached, wait 60 seconds and try again!");
    }
}

/*Functiom that is initialized when there are no respositories*/
function noResps() {
    alert("No respositories are available");
    document.getElementById("resname1").innerHTML = "Respository <br> name";
    document.getElementById("resname2").innerHTML = "Respository <br> name";
    document.getElementById("resname3").innerHTML = "Respository <br> name";
    return true;
}